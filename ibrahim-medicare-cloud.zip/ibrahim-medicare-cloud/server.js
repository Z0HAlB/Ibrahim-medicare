// ╔══════════════════════════════════════════════════════════════════╗
// ║   IBRAHIM MEDICARE — Cloud Server                               ║
// ║   Deploy to: Railway.app / Render.com / Any Node.js host       ║
// ╚══════════════════════════════════════════════════════════════════╝

const express  = require('express');
const Database = require('better-sqlite3');
const path     = require('path');
const fs       = require('fs');
const cors     = require('cors');
const os       = require('os');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Database path ─────────────────────────────────────────────────
// Railway: use /data volume if available, else local folder
const DATA_DIR = fs.existsSync('/data') ? '/data' : path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_PATH = path.join(DATA_DIR, 'ibrahim-medicare.db');
console.log('Database:', DB_PATH);

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ── Tables ────────────────────────────────────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL, role TEXT NOT NULL,
    name TEXT NOT NULL, spec TEXT DEFAULT ''
  );
  CREATE TABLE IF NOT EXISTS patients (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, mrNo TEXT UNIQUE NOT NULL,
    age TEXT, sex TEXT, contact TEXT, address TEXT,
    bp TEXT, pulse TEXT, rr TEXT, spo2 TEXT, temp TEXT, rbs TEXT, weight TEXT,
    assignedTo TEXT, status TEXT DEFAULT 'waiting',
    createdAt TEXT DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS prescriptions (
    id TEXT PRIMARY KEY, patientId TEXT NOT NULL,
    doctorId TEXT NOT NULL, doctorName TEXT,
    diagnosis TEXT, complaint TEXT, history TEXT, allergies TEXT,
    examination TEXT, investigations TEXT, medicines TEXT,
    instructions TEXT, referral TEXT, followup TEXT,
    image TEXT, vco INTEGER DEFAULT 0,
    dispenseStatus TEXT DEFAULT 'pending',
    dispensedAt TEXT, dispensedBy TEXT,
    date TEXT DEFAULT (datetime('now','localtime'))
  );
  CREATE TABLE IF NOT EXISTS pharmacy (
    id TEXT PRIMARY KEY, name TEXT NOT NULL,
    category TEXT, unit TEXT,
    price REAL DEFAULT 0, qty INTEGER DEFAULT 0,
    minLevel INTEGER DEFAULT 10, expiry TEXT
  );
`);

// ── Seed defaults ─────────────────────────────────────────────────
if (!db.prepare('SELECT COUNT(*) as c FROM users').get().c) {
  const ins = db.prepare('INSERT INTO users (id,username,password,role,name,spec) VALUES (?,?,?,?,?,?)');
  [
    ['admin1','admin',     'admin123',     'admin',     'Administrator',       ''],
    ['rec1',  'reception', 'reception123', 'reception', 'Receptionist',        ''],
    ['disp1', 'dispenser', 'dispenser123', 'dispenser', 'Dispenser',           ''],
    ['doc1',  'dr.ahmed',  'doctor123',    'doctor',    'Dr. Ahmed Bin Tahir', 'General Physician'],
    ['doc2',  'dr.zobia',  'doctor123',    'doctor',    'Dr. Zobia Iftikhar',  'General Physician'],
  ].forEach(r => ins.run(...r));
}
if (!db.prepare('SELECT COUNT(*) as c FROM pharmacy').get().c) {
  const pi = db.prepare('INSERT INTO pharmacy (id,name,category,unit,price,qty,minLevel,expiry) VALUES (?,?,?,?,?,?,?,?)');
  [
    ['ph1','Paracetamol 500mg','Analgesic','Tablet',5,200,20,'2026-12-31'],
    ['ph2','Amoxicillin 500mg','Antibiotic','Capsule',15,100,15,'2026-06-30'],
    ['ph3','Metformin 500mg','Antidiabetic','Tablet',8,150,20,'2026-09-30'],
    ['ph4','Omeprazole 20mg','Antacid','Capsule',12,80,10,'2026-08-31'],
    ['ph5','Atorvastatin 10mg','Lipid-lowering','Tablet',18,60,10,'2026-10-31'],
  ].forEach(r => pi.run(...r));
}

// ── Middleware ────────────────────────────────────────────────────
app.use(cors());
app.use(express.json({ limit: '20mb' }));
app.use(express.urlencoded({ extended: true, limit: '20mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ── AUTH ──────────────────────────────────────────────────────────
app.post('/api/login', (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE username=? AND password=?')
    .get(req.body.username, req.body.password);
  if (!u) return res.status(401).json({ error: 'Invalid credentials' });
  res.json(u);
});

// ── USERS ─────────────────────────────────────────────────────────
app.get('/api/users', (req, res) =>
  res.json(db.prepare('SELECT * FROM users').all()));

app.post('/api/users', (req, res) => {
  const { id, username, password, role, name, spec } = req.body;
  try {
    db.prepare('INSERT INTO users (id,username,password,role,name,spec) VALUES (?,?,?,?,?,?)')
      .run(id, username, password, role, name||'', spec||'');
    res.json({ success: true });
  } catch(e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/users/:id/password', (req, res) => {
  db.prepare('UPDATE users SET password=? WHERE id=?').run(req.body.password, req.params.id);
  res.json({ success: true });
});

app.delete('/api/users/:id', (req, res) => {
  db.prepare('DELETE FROM users WHERE id=?').run(req.params.id);
  res.json({ success: true });
});

// ── PATIENTS ──────────────────────────────────────────────────────
app.get('/api/patients', (req, res) =>
  res.json(db.prepare('SELECT * FROM patients ORDER BY createdAt DESC').all()));

app.post('/api/patients', (req, res) => {
  const p = req.body;
  try {
    db.prepare(`INSERT INTO patients
      (id,name,mrNo,age,sex,contact,address,bp,pulse,rr,spo2,temp,rbs,weight,assignedTo,status,createdAt)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(p.id,p.name,p.mrNo,p.age||'',p.sex||'',p.contact||'',p.address||'',
           p.bp||'',p.pulse||'',p.rr||'',p.spo2||'',p.temp||'',p.rbs||'',p.weight||'',
           p.assignedTo||'',p.status||'waiting',p.createdAt||new Date().toISOString());
    res.json({ success: true });
  } catch(e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/patients/:id', (req, res) => {
  db.prepare('UPDATE patients SET status=?,assignedTo=? WHERE id=?')
    .run(req.body.status, req.body.assignedTo, req.params.id);
  res.json({ success: true });
});

app.delete('/api/patients/:id', (req, res) => {
  db.prepare('DELETE FROM prescriptions WHERE patientId=?').run(req.params.id);
  db.prepare('DELETE FROM patients WHERE id=?').run(req.params.id);
  res.json({ success: true });
});

app.delete('/api/patients', (req, res) => {
  db.prepare('DELETE FROM prescriptions').run();
  db.prepare('DELETE FROM patients').run();
  res.json({ success: true });
});

// ── PRESCRIPTIONS ─────────────────────────────────────────────────
app.get('/api/prescriptions', (req, res) => {
  const rows = db.prepare('SELECT * FROM prescriptions ORDER BY date DESC').all();
  rows.forEach(r => { try { r.medicines = JSON.parse(r.medicines||'[]'); } catch { r.medicines=[]; }});
  res.json(rows);
});

app.post('/api/prescriptions', (req, res) => {
  const r = req.body;
  try {
    db.prepare(`INSERT INTO prescriptions
      (id,patientId,doctorId,doctorName,diagnosis,complaint,history,allergies,
       examination,investigations,medicines,instructions,referral,followup,
       image,vco,dispenseStatus,date)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
      .run(r.id,r.patientId,r.doctorId,r.doctorName||'',r.diagnosis||'',r.complaint||'',
           r.history||'',r.allergies||'',r.examination||'',r.investigations||'',
           JSON.stringify(r.medicines||[]),r.instructions||'',r.referral||'',r.followup||'',
           r.image||null,r.vco?1:0,r.dispenseStatus||'pending',r.date||new Date().toISOString());
    db.prepare("UPDATE patients SET status='seen' WHERE id=?").run(r.patientId);
    res.json({ success: true });
  } catch(e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/prescriptions/:id', (req, res) => {
  const r = req.body;
  db.prepare('UPDATE prescriptions SET dispenseStatus=?,dispensedAt=?,dispensedBy=? WHERE id=?')
    .run(r.dispenseStatus, r.dispensedAt||null, r.dispensedBy||null, req.params.id);
  res.json({ success: true });
});

app.delete('/api/prescriptions/:id', (req, res) => {
  db.prepare('DELETE FROM prescriptions WHERE id=?').run(req.params.id);
  res.json({ success: true });
});

app.delete('/api/prescriptions', (req, res) => {
  if (req.query.filter === 'dispensed') {
    db.prepare("DELETE FROM prescriptions WHERE dispenseStatus='dispensed'").run();
  } else {
    db.prepare('DELETE FROM prescriptions').run();
  }
  res.json({ success: true });
});

// ── PHARMACY ──────────────────────────────────────────────────────
app.get('/api/pharmacy', (req, res) =>
  res.json(db.prepare('SELECT * FROM pharmacy ORDER BY name').all()));

app.post('/api/pharmacy', (req, res) => {
  const p = req.body;
  try {
    db.prepare('INSERT INTO pharmacy (id,name,category,unit,price,qty,minLevel,expiry) VALUES (?,?,?,?,?,?,?,?)')
      .run(p.id,p.name,p.category||'',p.unit||'Tablet',p.price||0,p.qty||0,p.minLevel||10,p.expiry||'');
    res.json({ success: true });
  } catch(e) { res.status(400).json({ error: e.message }); }
});

app.put('/api/pharmacy/:id', (req, res) => {
  const p = req.body;
  db.prepare('UPDATE pharmacy SET name=?,category=?,unit=?,price=?,qty=?,minLevel=?,expiry=? WHERE id=?')
    .run(p.name,p.category||'',p.unit||'',p.price||0,p.qty||0,p.minLevel||10,p.expiry||'',req.params.id);
  res.json({ success: true });
});

app.delete('/api/pharmacy/:id', (req, res) => {
  db.prepare('DELETE FROM pharmacy WHERE id=?').run(req.params.id);
  res.json({ success: true });
});

// ── BACKUP / RESTORE ──────────────────────────────────────────────
app.get('/api/backup', (req, res) => {
  const rows = db.prepare('SELECT * FROM prescriptions').all();
  rows.forEach(r => { try { r.medicines = JSON.parse(r.medicines||'[]'); } catch { r.medicines=[]; }});
  const data = {
    users:         db.prepare('SELECT * FROM users').all(),
    patients:      db.prepare('SELECT * FROM patients').all(),
    prescriptions: rows,
    pharmacy:      db.prepare('SELECT * FROM pharmacy').all(),
    _meta: {
      exportedAt: new Date().toISOString(), version: 'ibrahim-medicare-v2',
      counts: {
        patients:      db.prepare('SELECT COUNT(*) as c FROM patients').get().c,
        prescriptions: db.prepare('SELECT COUNT(*) as c FROM prescriptions').get().c,
        pharmacy:      db.prepare('SELECT COUNT(*) as c FROM pharmacy').get().c,
        staff:         db.prepare('SELECT COUNT(*) as c FROM users').get().c,
      }
    }
  };
  res.setHeader('Content-Disposition',
    `attachment; filename="ibrahim-medicare-backup-${new Date().toISOString().slice(0,10)}.json"`);
  res.json(data);
});

app.post('/api/restore', (req, res) => {
  const data = req.body;
  if (!data._meta) return res.status(400).json({ error: 'Invalid backup' });
  try {
    db.transaction(() => {
      if (data.users?.length) {
        db.prepare('DELETE FROM users').run();
        const ui = db.prepare('INSERT OR REPLACE INTO users (id,username,password,role,name,spec) VALUES (?,?,?,?,?,?)');
        data.users.forEach(u => ui.run(u.id,u.username,u.password,u.role,u.name,u.spec||''));
      }
      db.prepare('DELETE FROM prescriptions').run();
      db.prepare('DELETE FROM patients').run();
      const pi = db.prepare(`INSERT OR REPLACE INTO patients
        (id,name,mrNo,age,sex,contact,address,bp,pulse,rr,spo2,temp,rbs,weight,assignedTo,status,createdAt)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
      (data.patients||[]).forEach(p =>
        pi.run(p.id,p.name,p.mrNo,p.age||'',p.sex||'',p.contact||'',p.address||'',
               p.bp||'',p.pulse||'',p.rr||'',p.spo2||'',p.temp||'',p.rbs||'',p.weight||'',
               p.assignedTo||'',p.status||'waiting',p.createdAt||''));
      const ri = db.prepare(`INSERT OR REPLACE INTO prescriptions
        (id,patientId,doctorId,doctorName,diagnosis,complaint,history,allergies,
         examination,investigations,medicines,instructions,referral,followup,
         image,vco,dispenseStatus,dispensedAt,dispensedBy,date)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
      (data.prescriptions||[]).forEach(r =>
        ri.run(r.id,r.patientId,r.doctorId,r.doctorName||'',r.diagnosis||'',r.complaint||'',
               r.history||'',r.allergies||'',r.examination||'',r.investigations||'',
               JSON.stringify(r.medicines||[]),r.instructions||'',r.referral||'',r.followup||'',
               r.image||null,r.vco?1:0,r.dispenseStatus||'pending',
               r.dispensedAt||null,r.dispensedBy||null,r.date||''));
      if (data.pharmacy?.length) {
        db.prepare('DELETE FROM pharmacy').run();
        const phi = db.prepare('INSERT OR REPLACE INTO pharmacy (id,name,category,unit,price,qty,minLevel,expiry) VALUES (?,?,?,?,?,?,?,?)');
        data.pharmacy.forEach(p => phi.run(p.id,p.name,p.category||'',p.unit||'Tablet',p.price||0,p.qty||0,p.minLevel||10,p.expiry||''));
      }
    })();
    res.json({ success: true, meta: data._meta });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── STATS ─────────────────────────────────────────────────────────
app.get('/api/stats', (req, res) => res.json({
  patients:        db.prepare('SELECT COUNT(*) as c FROM patients').get().c,
  waiting:         db.prepare("SELECT COUNT(*) as c FROM patients WHERE status='waiting'").get().c,
  prescriptions:   db.prepare('SELECT COUNT(*) as c FROM prescriptions').get().c,
  dispensed:       db.prepare("SELECT COUNT(*) as c FROM prescriptions WHERE dispenseStatus='dispensed'").get().c,
  pendingDispense: db.prepare("SELECT COUNT(*) as c FROM prescriptions WHERE dispenseStatus='pending'").get().c,
  pharmacy:        db.prepare('SELECT COUNT(*) as c FROM pharmacy').get().c,
  lowStock:        db.prepare('SELECT COUNT(*) as c FROM pharmacy WHERE qty <= minLevel').get().c,
}));

// ── Health check ──────────────────────────────────────────────────
app.get('/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

// ── Serve frontend ────────────────────────────────────────────────
app.get('*', (req, res) =>
  res.sendFile(path.join(__dirname, 'public', 'index.html')));

// ── Start ─────────────────────────────────────────────────────────
app.listen(PORT, '0.0.0.0', () => {
  console.log('');
  console.log('╔══════════════════════════════════════════════════════╗');
  console.log('║       IBRAHIM MEDICARE — Running!                   ║');
  console.log(`║  Port: ${String(PORT).padEnd(46)}║`);
  console.log(`║  DB:   ${DB_PATH.slice(-46).padEnd(46)}║`);
  console.log('╚══════════════════════════════════════════════════════╝');
});
